export const SortBy = [
    {
        id: 1,
        title: "sort by"
    },

    {
        id: 2,
        title: "Featured Products"
    },

    {
        id: 3,
        title: "New Arrivals"
    },

    {
        id: 4,
        title: "On sale"
    },

    {
        id: 5,
        title: "Best Sellings"
    },

    {
        id: 6,
        title: "Sort by price: low to high"
    },

    {
        id: 7,
        title: "Sort by price: high to low"
    },

    {
        id: 8,
        title: "Product Name: A to Z"
    },

    {
        id: 9,
        title: "Product Name: Z to A"
    },

]