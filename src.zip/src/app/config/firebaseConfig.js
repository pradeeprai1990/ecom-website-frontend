// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyArFT-IEvw8j13UWuclU3saI0Rx6_Xu99k",
  authDomain: "furniture-f77e5.firebaseapp.com",
  projectId: "furniture-f77e5",
  storageBucket: "furniture-f77e5.firebasestorage.app",
  messagingSenderId: "44701929372",
  appId: "1:44701929372:web:11b34e3b50bd74c8958259"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);